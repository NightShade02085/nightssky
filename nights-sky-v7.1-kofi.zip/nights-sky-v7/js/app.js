function wire(){
  document.querySelectorAll('.tool').forEach(b=>b.onclick=()=>setTool(b.dataset.tool));
  canvas.onmousedown=e=>{App.isDrawing=true;paint(e)};
  canvas.onmousemove=e=>{if(!App.isDrawing)return;dragPaint(e)};
  window.onmouseup=()=>{if(App.isDrawing)endPaint();App.isDrawing=false};
  canvas.ontouchstart=e=>{e.preventDefault();App.isDrawing=true;paint(e.touches[0])};
  canvas.ontouchmove=e=>{e.preventDefault();if(App.isDrawing)dragPaint(e.touches[0])};
  window.ontouchend=()=>{if(App.isDrawing)endPaint();App.isDrawing=false};
  if($('floatDeleteBtn'))$('floatDeleteBtn').onclick=delSel;
  if($('floatDeselectBtn'))$('floatDeselectBtn').onclick=clearSel;
  $('undoBtn').onclick=undo;$('redoBtn').onclick=redo;
  $('alphaRange').oninput=()=>setAlpha($('alphaRange').value);$('alphaNumber').oninput=()=>setAlpha($('alphaNumber').value);if($('colorQuickPicker'))$('colorQuickPicker').oninput=()=>{ $('colorPicker').value=$('colorQuickPicker').value; buildSwatches(); };$('colorPicker').oninput=()=>{ if($('colorQuickPicker'))$('colorQuickPicker').value=$('colorPicker').value; };
  $('paletteSearch').oninput=()=>{buildPaletteSelect();buildSwatches()};
  $('paletteSelect').onchange=()=>{App.activePaletteId=$('paletteSelect').value;buildSwatches();saveTab()};
  $('newPaletteBtn').onclick=newPalette;$('editPaletteBtn').onclick=editPalette;$('deletePaletteBtn').onclick=deletePalette;
  $('extractPaletteBtn').onclick=extractPaletteCurrent;$('exportPaletteBtn').onclick=exportPalette;$('importPaletteInput').onchange=e=>e.target.files[0]&&importPalette(e.target.files[0]);
  $('addFrameBtn').onclick=addFrame;$('duplicateFrameBtn').onclick=dupFrame;$('deleteFrameBtn').onclick=delFrame;$('playBtn').onclick=play;if($('playDirectionBtn'))$('playDirectionBtn').onclick=togglePlayDirection;if($('playLoopBtn'))$('playLoopBtn').onclick=togglePlayMode;
  $('addLayerBtn').onclick=addLayer;$('deleteLayerBtn').onclick=delLayer;$('mergeLayerBtn').onclick=mergeDown;
  $('newCanvasBtn').onclick=newTabPrompt;$('adjustCanvasBtn').onclick=adjustCanvas;
  $('toggleGridBtn').onclick=()=>{App.showGrid=!App.showGrid;draw()};
  $('gridColorPicker').oninput=()=>{App.gridColor=$('gridColorPicker').value;saveTab();draw()};
  $('gridFromDrawBtn').onclick=()=>{App.gridColor=$('colorPicker').value;$('gridColorPicker').value=App.gridColor;saveTab();draw()};
  $('zoomRange').oninput=()=>setZoomPixels(Number($('zoomRange').value));
  $('zoomNumber').oninput=()=>setZoomPercent(Number($('zoomNumber').value));
  $('brushSizeSelect').onchange=()=>App.brushSize=Number($('brushSizeSelect').value);
  $('brushShapeSelect').onchange=()=>App.brushShape=$('brushShapeSelect').value;
  $('selectModeSelect').onchange=()=>App.selectMode=$('selectModeSelect').value;
  $('fillModeSelect').onchange=()=>{App.fillMode=$('fillModeSelect').value;$('gradientOptions').classList.toggle('hidden',App.fillMode!=='gradient')};
  $('gradientColor').oninput=()=>App.gradientColor=$('gradientColor').value;
  $('gradientAlphaRange').oninput=()=>setGradientAlpha($('gradientAlphaRange').value);$('gradientAlphaNumber').oninput=()=>setGradientAlpha($('gradientAlphaNumber').value);
  $('gradientDirection').onchange=()=>App.gradientDirection=$('gradientDirection').value;
  $('dropperMaintainAlpha').onchange=()=>App.dropperMaintainAlpha=$('dropperMaintainAlpha').checked;
  $('shapeTypeSelect').onchange=()=>App.shapeType=$('shapeTypeSelect').value;
  $('shapeFilled').onchange=()=>App.shapeFilled=$('shapeFilled').checked;
  $('onionToggleBtn').onclick=()=>{App.onionSkin=!App.onionSkin;syncOnionUI();saveTab();draw()};
  $('prevNextGhostToggle').onchange=()=>{App.onionPrevNext=$('prevNextGhostToggle').checked;saveTab();draw()};
  $('customGhostToggle').onchange=()=>{App.onionCustomGhost=$('customGhostToggle').checked;saveTab();draw()};
  $('onionOpacityRange').oninput=()=>setPercentPair('onionOpacityRange','onionOpacityNumber',$('onionOpacityRange').value,v=>{App.onionOpacity=v/100;saveTab();draw()});
  $('onionOpacityNumber').oninput=()=>setPercentPair('onionOpacityRange','onionOpacityNumber',$('onionOpacityNumber').value,v=>{App.onionOpacity=v/100;saveTab();draw()});
  $('ghostTabSelect').onchange=()=>refreshGhostControls({keepTab:true,redraw:true});
  $('ghostFrameSelect').onchange=()=>refreshGhostControls({keepTab:true,keepFrame:true,redraw:true});
  $('ghostLayerSelect').onchange=()=>setGhostFromControls(true);
  $('saveTemplateBtn').onclick=saveTemplate;$('loadTemplateBtn').onclick=loadTemplate;$('toggleTemplateGhostBtn').onclick=toggleTemplateGhost;$('editTemplateBtn').onclick=editTemplate;$('deleteTemplateBtn').onclick=deleteTemplate;$('templateSearch').oninput=renderTemplates;$('templateSelect').onchange=()=>{updateTemplatePreview();syncTemplateQuickbar()};if($('templateQuickbarToggle'))$('templateQuickbarToggle').onchange=()=>{App.templateQuickbar=$('templateQuickbarToggle').checked;syncTemplateQuickbar()};if($('quickPasteTemplateBtn'))$('quickPasteTemplateBtn').onclick=loadTemplate;if($('quickGhostTemplateBtn'))$('quickGhostTemplateBtn').onclick=toggleTemplateGhost;if($('quickTemplateSelect'))$('quickTemplateSelect').onchange=()=>{$('templateSelect').value=$('quickTemplateSelect').value;updateTemplatePreview()};
  $('imageImportInput').onchange=e=>e.target.files[0]&&importImage(e.target.files[0]);
  $('exportProjectBtn').onclick=exportWizard;
  $('saveProjectBtn').onclick=saveProject;$('chooseProjectsFolderBtn').onclick=chooseProjectsFolder;$('loadProjectInput').onchange=e=>e.target.files[0]&&loadProjectFile(e.target.files[0]);
  $('timelineToggle').onclick=()=>{const t=$('timeline');t.classList.toggle('open');$('timelineToggle').textContent=t.classList.contains('open')?'Timeline ▼':'Timeline ▲';const tab=App.artTabs.find(t=>t.id===App.activeTabId);if(tab)tab.showTimeline=$('timeline').classList.contains('open');updateZoomDock()};
  wireModalSafety();
}
function wireModalSafety(){
  const modal=$('modal');
  if(!modal||modal.dataset.safeWired==='true')return;
  modal.dataset.safeWired='true';
  modal.onclick=e=>{if(e.target===modal)closeModal()};
  modal.addEventListener('pointerdown',e=>{
    if(e.target!==modal)e.stopPropagation();
  });
  modal.addEventListener('click',e=>{
    if(e.target!==modal)e.stopPropagation();
  });
}
function setZoomPixels(px){App.pixelSize=Math.max(2,Math.min(28,px));$('zoomRange').value=App.pixelSize;$('zoomNumber').value=Math.round(App.pixelSize/18*180);resizeCanvas();saveTab();draw()}
function setZoomPercent(pct){const px=Math.max(2,Math.min(28,Math.round((pct/180)*18)));setZoomPixels(px)}
function syncOnionUI(){if($('onionToggleBtn'))$('onionToggleBtn').textContent=App.onionSkin?'Onion Skin: On':'Onion Skin: Off';if($('prevNextGhostToggle'))$('prevNextGhostToggle').checked=App.onionPrevNext!==false;if($('customGhostToggle'))$('customGhostToggle').checked=App.onionCustomGhost!==false;if($('onionOpacityRange'))setPercentPair('onionOpacityRange','onionOpacityNumber',Math.round((App.onionOpacity||.35)*100));}
loadLocalMeta();wire();initProject();buildPaletteSelect();buildSwatches();renderTemplates();updateTemplatePreview();syncTemplateQuickbar();updateHistoryButtons();updateSelectionUI();maybeAskProjectsFolder();

function updateZoomDock(){
  const z=$('zoomDock'),t=$('timeline');if(!z||!t)return;
  z.style.bottom=(t.classList.contains('open')?(t.offsetHeight+8):18)+'px';
}
window.addEventListener('resize',updateZoomDock);
setTimeout(updateZoomDock,500);
