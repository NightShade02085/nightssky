function switchTab(tabId){stopPlay();saveTab();const t=App.artTabs.find(t=>t.id===tabId);if(!t)return;App.activeTabId=t.id;App.width=t.width;App.height=t.height;App.gridSize=t.width;App.pixelSize=t.pixelSize||App.pixelSize;App.frames=t.frames;App.activeFrameId=t.activeFrameId;App.frameCounter=t.frameCounter;App.layers=t.layers;App.activeLayerId=t.activeLayerId;App.layerCounter=t.layerCounter;App.selection=t.selection;App.selectionCells=t.selectionCells?new Set(t.selectionCells):null;App.ghost=t.ghost;App.gridColor=t.gridColor||App.gridColor;App.onionSkin=!!t.onionSkin;App.onionOpacity=t.onionOpacity||.35;App.onionPrevNext=t.onionPrevNext!==false;App.onionCustomGhost=t.onionCustomGhost!==false;App.activePaletteId=t.paletteId||App.activePaletteId;resizeCanvas();$('zoomRange').value=String(App.pixelSize);if($('zoomNumber'))$('zoomNumber').value=Math.round(App.pixelSize/18*180);if($('gridColorPicker'))$('gridColorPicker').value=App.gridColor;document.getElementById('timeline').classList.toggle('open',t.showTimeline!==false);setTimeout(updateZoomDock,0);renderTabs();renderFrames();renderLayers();buildPaletteSelect();$('paletteSelect').value=App.activePaletteId;buildSwatches();refreshGhostControls();syncOnionUI();draw()}
function newTabPrompt(){showModal(`<h2>New Project / Tab</h2><label>Name</label><input id="mName" value="Tab ${App.tabCounter+1}"><div class="row2"><div><label>Width</label><input id="mW" type="number" min="1" max="11000" value="32"></div><div><label>Height</label><input id="mH" type="number" min="1" max="11000" value="32"></div></div><label>Palette</label><select id="mPalette">${allPalettes().map(p=>`<option value="${p.id}">${p.name}</option>`).join('')}</select><label>Mode</label><select id="mMode"><option value="sprite">Sprite / Still Image</option><option value="animation">Animation Timeline Visible</option></select><p class="hint">Large canvases can become slow. Anything over 2048 x 2048 may strain your browser.</p><div class="modal-actions"><button onclick="closeModal()">Cancel</button><button class="primary" onclick="createNewTabFromModal()">Create</button></div>`)}
function createNewTabFromModal(){const w=Math.min(11000,Math.max(1,Number($('mW').value)||32)),h=Math.min(11000,Math.max(1,Number($('mH').value)||32));if(w*h>4000000&&!confirm('This is a very large canvas and may be slow. Create it anyway?'))return;App.tabCounter++;const t=createTab($('mName').value||('Tab '+App.tabCounter),w,h,$('mMode').value==='animation',$('mPalette').value);t.paletteId=$('mPalette').value;App.artTabs.push(t);closeModal();switchTab(t.id)}
function adjustCanvas(){showModal(`<h2>Adjust Canvas Size</h2><div class="row2"><div><label>New Width</label><input id="aw" type="number" min="1" max="11000" value="${App.width}"></div><div><label>New Height</label><input id="ah" type="number" min="1" max="11000" value="${App.height}"></div></div><p class="hint">Existing pixels outside the new size will be clipped.</p><div class="modal-actions"><button onclick="closeModal()">Cancel</button><button class="primary" onclick="resizeProjectFromModal()">Resize</button></div>`)}
function resizeProjectFromModal(){const w=Math.min(11000,Math.max(1,Number($('aw').value)||App.width)),h=Math.min(11000,Math.max(1,Number($('ah').value)||App.height));if(w*h>4000000&&!confirm('This is a very large canvas and may be slow. Resize anyway?'))return;App.frames.forEach(f=>f.layers.forEach(l=>{const np=Array.from({length:h},(_,y)=>Array.from({length:w},(_,x)=>l.pixels[y]?.[x]||null));l.pixels=np}));App.width=w;App.height=h;resizeCanvas();saveTab();closeModal();draw()}
async function saveProject(){saveTab();const data={version:2,artTabs:App.artTabs,activeTabId:App.activeTabId,palettes:App.palettes,recent:App.recent,templates:App.templates};const name=((App.artTabs.find(t=>t.id===App.activeTabId)?.name)||'pixel-project').replace(/[^a-z0-9-_ ]/gi,'_')+'.json';if(App.projectsDirHandle&&window.showDirectoryPicker){try{const fh=await App.projectsDirHandle.getFileHandle(name,{create:true});const w=await fh.createWritable();await w.write(JSON.stringify(data,null,2));await w.close();alert('Project saved to chosen Projects folder.');return}catch(e){console.warn(e)}}downloadJSON(data,name)}
function loadProjectFile(file){const r=new FileReader();r.onload=()=>{try{const data=JSON.parse(r.result);App.artTabs=data.artTabs||[];App.activeTabId=null;App.palettes=data.palettes||App.palettes;App.recent=data.recent||App.recent;App.templates=data.templates||App.templates;App.tabCounter=App.artTabs.length;if(!App.artTabs.length)App.artTabs=[createTab('Tab 1',32,32)];switchTab(data.activeTabId||App.artTabs[0].id);saveLocalMeta();renderTemplates()}catch(e){alert('Could not load project JSON.')}};r.readAsText(file)}
function downloadJSON(data,name){const a=document.createElement('a');a.download=name;a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'}));a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}
function showModal(html){$('modalContent').innerHTML=html;$('modal').classList.remove('hidden')}
function closeModal(){$('modal').classList.add('hidden')}
function initProject(){App.tabCounter=1;App.artTabs=[createTab('Tab 1',32,32,true)];resetHistory();switchTab(App.artTabs[0].id)}
function confirmAction(title,message,onYes){showModal(`<h2>${title}</h2><p class="hint">${message||''}</p><div class="modal-actions"><button onclick="closeModal()">Cancel</button><button class="danger" id="confirmYesBtn">Confirm</button></div>`);setTimeout(()=>{$('confirmYesBtn').onclick=()=>{closeModal();onYes&&onYes()}},0)}


function closeTab(tabId){
  if(App.artTabs.length<=1){alert('You need at least one open tab.');return}
  const t=App.artTabs.find(x=>x.id===tabId);if(!t)return;
  showModal(`<h2>Close "${t.name}"?</h2><p class="hint">Do you want to save this project before closing the tab?</p><div class="modal-actions"><button onclick="closeModal()">Cancel</button><button onclick="closeModal();closeTabNow('${tabId}')">Close Without Saving</button><button class="primary" onclick="closeModal();saveProject().then(()=>closeTabNow('${tabId}'))">Save & Close</button></div>`);
}
function closeTabNow(tabId){
  const i=App.artTabs.findIndex(t=>t.id===tabId);if(i<0)return;
  App.artTabs.splice(i,1);
  const next=App.artTabs[Math.max(0,i-1)]||App.artTabs[0];
  switchTab(next.id);
}
function reorderTab(fromId,toId){
  if(!fromId||fromId===toId)return;
  const from=App.artTabs.findIndex(t=>t.id===fromId),to=App.artTabs.findIndex(t=>t.id===toId);
  if(from<0||to<0)return;
  const [tab]=App.artTabs.splice(from,1);App.artTabs.splice(to,0,tab);renderTabs();saveTab();
}
function maybeAskProjectsFolder(){
  if(!window.showDirectoryPicker||localStorage.getItem('nightsSkyFolderPrompted'))return;
  localStorage.setItem('nightsSkyFolderPrompted','1');
  setTimeout(()=>showModal(`<h2>Choose a Projects Folder?</h2><p class="hint">Night's Sky can save project JSON files directly into a folder you choose when your browser supports it. You can select an existing Projects folder or create one in the browser picker. You can also skip this and use normal downloads.</p><div class="modal-actions"><button onclick="closeModal()">Skip</button><button class="primary" onclick="closeModal();chooseProjectsFolder()">Choose Folder</button></div>`),400);
}

async function chooseProjectsFolder(){
  if(!window.showDirectoryPicker){alert('Your browser does not allow a local app to save directly into a folder. Save Project will use normal downloads instead.');return}
  try{App.projectsDirHandle=await window.showDirectoryPicker({mode:'readwrite'});alert('Projects folder connected for this session. Browser security requires permission again after reload.')}catch(e){}
}
