const canvas=$('pixelCanvas'),ctx=canvas.getContext('2d');
function resizeCanvas(){canvas.width=App.width*App.pixelSize;canvas.height=App.height*App.pixelSize}
function drawLayers(ls,op=1,tint=null){ctx.globalAlpha=op;for(let i=ls.length-1;i>=0;i--){const l=ls[i];if(!l.visible)continue;for(let y=0;y<App.height;y++)for(let x=0;x<App.width;x++){const c=l.pixels[y]?.[x];if(c){ctx.fillStyle=tint||c;ctx.fillRect(x*App.pixelSize,y*App.pixelSize,App.pixelSize,App.pixelSize)}}}ctx.globalAlpha=1}
function drawOnion(){if(!App.onionSkin||App.isPlaying)return;const i=App.frames.findIndex(f=>f.id===App.activeFrameId);if(App.onionPrevNext!==false){if(App.frames[i-1])drawLayers(App.frames[i-1].layers,App.onionOpacity,'#3b82f6');if(App.frames[i+1])drawLayers(App.frames[i+1].layers,App.onionOpacity,'#ef4444')}if(App.onionCustomGhost!==false&&App.ghost){let layers=null;if(App.ghost.type==='layer'){const t=App.artTabs.find(t=>t.id===App.ghost.tabId);const f=t?.frames.find(f=>f.id===App.ghost.frameId);const l=f?.layers.find(l=>l.id===App.ghost.layerId);if(l)layers=[l]}else if(App.ghost.type==='template'){const temp=App.templates.find(t=>t.id===App.ghost.templateId);if(temp)layers=[{visible:true,pixels:temp.pixels}]}if(layers)drawLayers(layers,App.onionOpacity,'#facc15')}}
function drawFloat(){if(!App.selectionMode||!App.selectedPixels||!App.selection)return;ctx.globalAlpha=.8;for(let y=0;y<App.selection.h;y++)for(let x=0;x<App.selection.w;x++){const c=App.selectedPixels[y][x];if(c){ctx.fillStyle=c;ctx.fillRect((App.selection.x+x)*App.pixelSize,(App.selection.y+y)*App.pixelSize,App.pixelSize,App.pixelSize)}}ctx.globalAlpha=1}
function drawSel(){
  if(!App.selection)return;
  ctx.save();
  if(App.selectionCells){
    ctx.globalAlpha=.22;ctx.fillStyle='#ffffff';
    App.selectionCells.forEach(k=>{const [x,y]=k.split(',').map(Number);ctx.fillRect(x*App.pixelSize,y*App.pixelSize,App.pixelSize,App.pixelSize)});
    ctx.globalAlpha=1;
  }
  if(App.lassoPoints&&App.lassoPoints.length>1){
    ctx.strokeStyle='#facc15';ctx.setLineDash([3,3]);ctx.beginPath();
    ctx.moveTo(App.lassoPoints[0].x*App.pixelSize+App.pixelSize/2,App.lassoPoints[0].y*App.pixelSize+App.pixelSize/2);
    App.lassoPoints.slice(1).forEach(p=>ctx.lineTo(p.x*App.pixelSize+App.pixelSize/2,p.y*App.pixelSize+App.pixelSize/2));
    ctx.stroke();
  }
  ctx.setLineDash([6,4]);ctx.lineWidth=2;ctx.strokeStyle='#000';
  ctx.strokeRect(App.selection.x*App.pixelSize+1,App.selection.y*App.pixelSize+1,App.selection.w*App.pixelSize-2,App.selection.h*App.pixelSize-2);
  ctx.lineWidth=1;ctx.strokeStyle='#fff';
  ctx.strokeRect(App.selection.x*App.pixelSize+2,App.selection.y*App.pixelSize+2,App.selection.w*App.pixelSize-4,App.selection.h*App.pixelSize-4);
  ctx.restore()
}
function drawShapePreview(){if(!App.shapePreview)return;ctx.save();ctx.globalAlpha=.72;ctx.fillStyle=paintColor();const cells=shapeCells(App.shapePreview);for(const [x,y] of cells){ctx.fillRect(x*App.pixelSize,y*App.pixelSize,App.pixelSize,App.pixelSize)}ctx.globalAlpha=1;ctx.strokeStyle='rgba(255,255,255,.75)';ctx.setLineDash([4,3]);ctx.strokeRect(App.shapePreview.x*App.pixelSize+.5,App.shapePreview.y*App.pixelSize+.5,App.shapePreview.w*App.pixelSize,App.shapePreview.h*App.pixelSize);ctx.restore()}
function drawGrid(){if(!App.showGrid||App.pixelSize<4)return;ctx.strokeStyle=App.gridColor||'rgba(0,0,0,.18)';ctx.globalAlpha=.35;for(let i=0;i<=App.width;i++){ctx.beginPath();ctx.moveTo(i*App.pixelSize+.5,0);ctx.lineTo(i*App.pixelSize+.5,canvas.height);ctx.stroke()}for(let i=0;i<=App.height;i++){ctx.beginPath();ctx.moveTo(0,i*App.pixelSize+.5);ctx.lineTo(canvas.width,i*App.pixelSize+.5);ctx.stroke()}ctx.globalAlpha=1}
function draw(){ctx.clearRect(0,0,canvas.width,canvas.height);drawOnion();drawLayers(App.layers);drawFloat();drawShapePreview();drawSel();drawGrid();renderFrameThumbs();updateSelectionUI()}
function renderTabs(){
  const tabsBar=$('tabsBar');tabsBar.innerHTML='';
  App.artTabs.forEach((t,idx)=>{
    const b=document.createElement('button');
    b.className='tab'+(t.id===App.activeTabId?' active':'');
    b.draggable=true;b.dataset.tabId=t.id;
    const name=document.createElement('span');name.className='tab-name';name.textContent=t.name;
    const close=document.createElement('span');close.className='tab-close';close.textContent='×';close.title='Close tab';
    close.onclick=e=>{e.stopPropagation();closeTab(t.id)};
    b.append(name,close);
    b.ondblclick=()=>{const n=prompt('Rename tab:',t.name);if(n&&n.trim()){t.name=n.trim();renderTabs();refreshGhostControls({redraw:true})}};
    b.onclick=()=>switchTab(t.id);
    b.ondragstart=e=>{e.dataTransfer.setData('text/plain',t.id);b.classList.add('dragging')};
    b.ondragend=()=>b.classList.remove('dragging');
    b.ondragover=e=>e.preventDefault();
    b.ondrop=e=>{e.preventDefault();const from=e.dataTransfer.getData('text/plain');reorderTab(from,t.id)};
    tabsBar.appendChild(b)
  })
}
function renderLayers(){const el=$('layersList');el.innerHTML='';App.layers.forEach((l,i)=>{const d=document.createElement('div');d.className='layer-item'+(l.id===App.activeLayerId?' active':'');const v=document.createElement('button');v.textContent=l.visible?'👁':'🚫';v.onclick=()=>{l.visible=!l.visible;saveTab();renderLayers();draw()};const n=document.createElement('div');n.className='layer-name';n.textContent=l.name;n.onclick=()=>{App.activeLayerId=l.id;saveTab();renderLayers();refreshGhostControls()};n.ondblclick=()=>{const x=prompt('Rename layer:',l.name);if(x&&x.trim()){l.name=x.trim();saveTab();renderLayers();refreshGhostControls()}};const up=document.createElement('button');up.textContent='↑';up.onclick=()=>{if(i>0){pushHistory('Layer order');[App.layers[i-1],App.layers[i]]=[App.layers[i],App.layers[i-1]];saveTab();renderLayers();draw()}};d.append(v,n,up);el.appendChild(d)})}
function drawFrameToCanvas(c,f,w=App.width,h=App.height){const tc=c.getContext('2d');tc.clearRect(0,0,c.width,c.height);tc.imageSmoothingEnabled=false;const scale=Math.max(1,Math.floor(Math.min(c.width/w,c.height/h)));const ox=Math.floor((c.width-w*scale)/2),oy=Math.floor((c.height-h*scale)/2);f.layers.slice().reverse().forEach(l=>{if(!l.visible)return;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const col=l.pixels[y]?.[x];if(col){tc.fillStyle=col;tc.fillRect(ox+x*scale,oy+y*scale,scale,scale)}}})}
function renderFrameThumbs(){document.querySelectorAll('canvas.frame-thumb').forEach(c=>{const f=App.frames.find(fr=>fr.id===c.dataset.frameId);if(f)drawFrameToCanvas(c,f)})}

// ===== V5 layer drag ordering and masked float drawing =====
function reorderLayer(fromId,toId){
  if(!fromId||!toId||fromId===toId)return;
  pushHistory('Layer order');
  const from=App.layers.findIndex(l=>l.id===fromId),to=App.layers.findIndex(l=>l.id===toId);
  if(from<0||to<0)return;
  const [l]=App.layers.splice(from,1);App.layers.splice(to,0,l);
  saveTab();renderLayers();refreshGhostControls({redraw:true});draw();
}
const __v5_renderLayers = renderLayers;
renderLayers = function(){
  __v5_renderLayers();
  document.querySelectorAll('.layer-item').forEach((d,i)=>{
    const layer=App.layers[i]; if(!layer)return;
    d.draggable=true; d.dataset.layerId=layer.id;
    d.ondragstart=e=>{e.dataTransfer.setData('text/plain',layer.id);d.classList.add('dragging')};
    d.ondragend=()=>d.classList.remove('dragging');
    d.ondragover=e=>e.preventDefault();
    d.ondrop=e=>{e.preventDefault();reorderLayer(e.dataTransfer.getData('text/plain'),layer.id)};
  });
};
