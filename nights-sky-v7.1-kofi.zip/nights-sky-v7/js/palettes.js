const builtIn=[{id:'quick',name:'Quick Colors',colors:['#000000','#ffffff','#8b5cf6','#ef4444','#f97316','#facc15','#22c55e','#06b6d4','#3b82f6','#a855f7','#ec4899','#78716c']},{id:'gray',name:'Grayscale',colors:['#000000','#1a1a1a','#333333','#4d4d4d','#666666','#808080','#999999','#b3b3b3','#cccccc','#e6e6e6','#f2f2f2','#ffffff']}];
function allPalettes(){return [...builtIn,...App.palettes,{id:'recent',name:'Recent Colors',colors:App.recent}]}
function userPalette(){return App.palettes.find(p=>p.id===App.activePaletteId)}
function rgba(hex,a){const r=parseInt(hex.slice(1,3),16),g=parseInt(hex.slice(3,5),16),b=parseInt(hex.slice(5,7),16);return`rgba(${r}, ${g}, ${b}, ${a})`}
function paintColor(){return rgba($('colorPicker').value,App.currentAlpha)}
function gradientEndColor(){return rgba(App.gradientColor||$('gradientColor')?.value||'#ffffff',App.gradientAlpha??1)}
function setAlpha(v){const c=Math.max(0,Math.min(100,Number(v)||0));App.currentAlpha=c/100;$('alphaRange').value=c;$('alphaNumber').value=c}
function setGradientAlpha(v){const c=Math.max(0,Math.min(100,Number(v)||0));App.gradientAlpha=c/100;$('gradientAlphaRange').value=c;$('gradientAlphaNumber').value=c}
function remember(c){if(!c)return;App.recent=App.recent.filter(x=>x!==c);App.recent.unshift(c);App.recent=App.recent.slice(0,12);saveLocalMeta();buildPaletteSelect();buildSwatches()}
function parseColor(c,keepCurrentAlpha=false){const oldAlpha=App.currentAlpha;if(c[0]==='#'){$('colorPicker').value=c;if(!keepCurrentAlpha)setAlpha(100);else setAlpha(Math.round(oldAlpha*100));return}const m=c.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([0-9.]+))?\)/);if(!m)return;$('colorPicker').value='#'+[1,2,3].map(i=>Number(m[i]).toString(16).padStart(2,'0')).join('');if(keepCurrentAlpha)setAlpha(Math.round(oldAlpha*100));else setAlpha(m[4]!==undefined?Math.round(Number(m[4])*100):100)}
function buildPaletteSelect(){const s=$('paletteSelect'),cur=s.value||App.activePaletteId,term=($('paletteSearch')?.value||'').toLowerCase();s.innerHTML='';allPalettes().filter(p=>!term||p.name.toLowerCase().includes(term)).forEach(p=>{const o=document.createElement('option');o.value=p.id;o.textContent=p.name;s.appendChild(o)});s.value=[...s.options].some(o=>o.value===cur)?cur:(s.options[0]?.value||'quick');App.activePaletteId=s.value}
function buildSwatches(){const p=allPalettes().find(p=>p.id===App.activePaletteId)||builtIn[0];$('swatches').innerHTML='';$('colorBarHint').textContent=`${p.name}: ${p.colors.length}/32 colors${userPalette()?' • editable':''}`;p.colors.slice(0,32).forEach(c=>{const b=document.createElement('button');b.className='swatch';b.style.background=c;b.title=c;b.onclick=()=>{parseColor(c);setTool('draw')};b.oncontextmenu=e=>{e.preventDefault();if(userPalette())removeColorFromPalette(c)};$('swatches').appendChild(b)});updatePaletteButtons()}
function paletteColorsFromRaw(raw){return (raw||'').split(/[\s,]+/).map(x=>x.trim()).filter(x=>/^#[0-9a-fA-F]{6}$/.test(x)).slice(0,32)}
function newPalette(){const name=prompt('Palette name:','New Palette');if(!name)return;const raw=prompt('Enter up to 32 hex colors separated by commas or spaces:', $('colorPicker').value);const colors=paletteColorsFromRaw(raw);App.palettes.push({id:uid(),name,colors});saveLocalMeta();buildPaletteSelect();$('paletteSelect').value=App.palettes.at(-1).id;App.activePaletteId=$('paletteSelect').value;buildSwatches()}
function editPalette(){const p=userPalette();if(!p)return alert('Built-in and Recent palettes cannot be edited. Create a custom palette first.');const name=prompt('Palette name:',p.name);if(!name)return;const raw=prompt('Edit up to 32 hex colors:',p.colors.join(', '));if(raw===null)return;p.name=name;p.colors=paletteColorsFromRaw(raw);saveLocalMeta();buildPaletteSelect();$('paletteSelect').value=p.id;App.activePaletteId=p.id;buildSwatches()}
function deletePalette(){const p=userPalette();if(!p)return alert('Built-in and Recent palettes cannot be deleted.');confirmAction('Delete palette?','This removes the custom palette from local storage.',()=>{App.palettes=App.palettes.filter(x=>x.id!==p.id);App.activePaletteId='quick';saveLocalMeta();buildPaletteSelect();buildSwatches()})}
function removeColorFromPalette(c){const p=userPalette();if(!p)return;p.colors=p.colors.filter(x=>x!==c);saveLocalMeta();buildSwatches()}
function updatePaletteButtons(){const editable=!!userPalette();['editPaletteBtn','deletePaletteBtn'].forEach(id=>{const el=$(id);if(el)el.disabled=!editable})}
function saveLocalMeta(){localStorage.setItem('pixelStudioMeta',JSON.stringify({palettes:App.palettes,templates:App.templates,recent:App.recent}))}
function loadLocalMeta(){try{const m=JSON.parse(localStorage.getItem('pixelStudioMeta')||'{}');App.palettes=m.palettes||[];App.templates=m.templates||[];App.recent=m.recent||[]}catch(e){}}


// ===== V4 friendly palette editor =====
function paletteEditorModal(mode,pal=null){
  App.paletteDraft={id:pal?.id||uid(),name:pal?.name||'New Palette',colors:[...(pal?.colors||[$('colorPicker').value])].slice(0,32),editing:!!pal};
  renderPaletteEditor(mode);
}
function renderPaletteEditor(mode='Create'){
  const d=App.paletteDraft;
  showModal(`<h2>${mode} Palette</h2>
    <label>Palette Name</label><input id="peName" value="${d.name.replace(/"/g,'&quot;')}">
    <p class="hint">Use the normal color picker in the toolbar, then click “Add Current Color.” You can also click any color below to load it into the picker, or remove colors one by one.</p>
    <div class="tool-row"><button id="peAddCurrent">Add Current Color</button><button id="peUseActive">Copy Active Palette</button></div>
    <div id="paletteEditorSwatches" class="swatches"></div>
    <p class="hint">${d.colors.length}/32 colors</p>
    <div class="modal-actions"><button onclick="closeModal()">Cancel</button><button class="primary" id="peSave">${mode} Palette</button></div>`);
  setTimeout(()=>{
    const box=$('paletteEditorSwatches');box.innerHTML='';
    d.colors.forEach((c,i)=>{const b=document.createElement('button');b.className='swatch';b.style.background=c;b.title='Click to use, right-click to remove';b.onclick=()=>parseColor(c);b.oncontextmenu=e=>{e.preventDefault();d.colors.splice(i,1);renderPaletteEditor(mode)};box.appendChild(b)});
    $('peAddCurrent').onclick=()=>{const c=$('colorPicker').value;if(!d.colors.includes(c)&&d.colors.length<32)d.colors.push(c);renderPaletteEditor(mode)};
    $('peUseActive').onclick=()=>{const p=allPalettes().find(p=>p.id===App.activePaletteId);if(p)d.colors=[...p.colors].slice(0,32);renderPaletteEditor(mode)};
    $('peSave').onclick=()=>{const name=$('peName').value.trim()||'Palette'; if(d.editing){const p=App.palettes.find(x=>x.id===d.id);if(p){p.name=name;p.colors=d.colors.slice(0,32)}}else{App.palettes.push({id:d.id,name,colors:d.colors.slice(0,32)})}App.activePaletteId=d.id;saveLocalMeta();closeModal();buildPaletteSelect();$('paletteSelect').value=d.id;buildSwatches()};
  },0)
}
function newPalette(){paletteEditorModal('Create')}
function editPalette(){const p=userPalette();if(!p)return alert('Built-in and Recent palettes cannot be edited. Create a custom palette first.');paletteEditorModal('Edit',p)}

// ===== V5 active color chip sync =====
const __v5_parseColor = parseColor;
parseColor = function(c, keepCurrentAlpha=false){
  __v5_parseColor(c, keepCurrentAlpha);
  if($('colorQuickPicker')) $('colorQuickPicker').value = $('colorPicker').value;
};
const __v5_setAlpha = setAlpha;
setAlpha = function(v){
  __v5_setAlpha(v);
  if($('colorQuickPicker')) $('colorQuickPicker').value = $('colorPicker').value;
};

// ===== V6 visual palette builder =====
const PALETTE_PLACEHOLDER_COLOR = '#c4b5fd';
function hexToParts(hex){
  hex = /^#[0-9a-fA-F]{6}$/.test(hex||'') ? hex : PALETTE_PLACEHOLDER_COLOR;
  return {
    r: parseInt(hex.slice(1,3),16),
    g: parseInt(hex.slice(3,5),16),
    b: parseInt(hex.slice(5,7),16)
  };
}
function partsToHex(r,g,b){
  return '#'+[r,g,b].map(v=>Math.max(0,Math.min(255,Number(v)||0)).toString(16).padStart(2,'0')).join('');
}
function selectedDraftColor(){
  const d=App.paletteDraft;
  if(!d.colors.length){d.colors.push(PALETTE_PLACEHOLDER_COLOR);d.selectedIndex=0}
  if(d.selectedIndex==null||d.selectedIndex<0||d.selectedIndex>=d.colors.length)d.selectedIndex=0;
  return d.colors[d.selectedIndex];
}
function setDraftSelectedColor(hex){
  const d=App.paletteDraft;if(!d)return;
  if(d.selectedIndex==null||d.selectedIndex<0)return;
  d.colors[d.selectedIndex]=hex;
  renderPaletteEditorControls();
  renderPaletteEditorSlots();
}
function paletteEditorModal(mode,pal=null){
  App.paletteDraft={
    id:pal?.id||uid(),
    name:pal?.name||'New Palette',
    colors:[...(pal?.colors||[])].filter(c=>/^#[0-9a-fA-F]{6}$/.test(c)).slice(0,32),
    selectedIndex:0,
    editing:!!pal,
    mode
  };
  if(!App.paletteDraft.colors.length){
    App.paletteDraft.colors.push(PALETTE_PLACEHOLDER_COLOR);
  }
  renderPaletteEditor(mode);
}
function renderPaletteEditor(mode='Create'){
  const d=App.paletteDraft;
  const safeName=(d.name||'New Palette').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');
  showModal(`<h2>${mode} Palette</h2>
    <label>Palette Name</label><input id="peName" value="${safeName}">
    <p class="hint">Click an empty slot to add a light-purple color, then edit it with the RGB controls. Existing color slots can be selected, replaced, copied from the active draw color, or removed.</p>
    <div class="palette-builder-top">
      <div>
        <label>Palette Slots</label>
        <div id="paletteEditorSwatches" class="palette-builder-grid"></div>
        <p id="paletteBuilderCount" class="hint"></p>
      </div>
      <div class="palette-builder-controls">
        <label>Selected Color</label>
        <div class="selected-color-row">
          <button id="peReplaceCurrent" class="swatch palette-action-swatch" title="Replace selected color with active draw color">↺</button>
          <input id="peColorInput" type="color" value="${selectedDraftColor()}">
        </div>
        <div class="rgb-row"><label>R</label><input id="peR" type="range" min="0" max="255"><input id="peRN" type="number" min="0" max="255"></div>
        <div class="rgb-row"><label>G</label><input id="peG" type="range" min="0" max="255"><input id="peGN" type="number" min="0" max="255"></div>
        <div class="rgb-row"><label>B</label><input id="peB" type="range" min="0" max="255"><input id="peBN" type="number" min="0" max="255"></div>
        <div class="palette-builder-actions">
          <button id="peUseDrawColor">Use Draw Color</button>
          <button id="peRemoveSelected" class="danger">Remove Selected</button>
          <button id="peCopyActive">Copy Active Palette</button>
          <button id="peClearAll" class="danger">Clear All</button>
        </div>
      </div>
    </div>
    <div class="modal-actions"><button onclick="closeModal()">Cancel</button><button class="primary" id="peSave">${mode} Palette</button></div>`);
  setTimeout(()=>{
    renderPaletteEditorSlots();
    renderPaletteEditorControls();
    $('peReplaceCurrent').onclick=()=>{setDraftSelectedColor($('colorPicker').value)};
    $('peUseDrawColor').onclick=()=>{setDraftSelectedColor($('colorPicker').value)};
    $('peRemoveSelected').onclick=()=>{const d=App.paletteDraft;if(d.colors.length){d.colors.splice(d.selectedIndex,1);d.selectedIndex=Math.max(0,Math.min(d.selectedIndex,d.colors.length-1));if(!d.colors.length){d.colors.push(PALETTE_PLACEHOLDER_COLOR);d.selectedIndex=0}renderPaletteEditorSlots();renderPaletteEditorControls();}};
    $('peCopyActive').onclick=()=>{const p=allPalettes().find(p=>p.id===App.activePaletteId);if(p){d.colors=[...p.colors].filter(c=>/^#[0-9a-fA-F]{6}$/.test(c)).slice(0,32);if(!d.colors.length)d.colors=[PALETTE_PLACEHOLDER_COLOR];d.selectedIndex=0;renderPaletteEditorSlots();renderPaletteEditorControls();}};
    $('peClearAll').onclick=()=>{d.colors=[PALETTE_PLACEHOLDER_COLOR];d.selectedIndex=0;renderPaletteEditorSlots();renderPaletteEditorControls();};
    $('peSave').onclick=()=>{const name=$('peName').value.trim()||'Palette';const colors=d.colors.filter(c=>/^#[0-9a-fA-F]{6}$/.test(c)).slice(0,32);if(d.editing){const p=App.palettes.find(x=>x.id===d.id);if(p){p.name=name;p.colors=colors}}else{App.palettes.push({id:d.id,name,colors})}App.activePaletteId=d.id;saveLocalMeta();closeModal();buildPaletteSelect();$('paletteSelect').value=d.id;buildSwatches();};
  },0);
}
function renderPaletteEditorSlots(){
  const d=App.paletteDraft, box=$('paletteEditorSwatches'); if(!box)return;
  box.innerHTML='';
  d.colors.forEach((c,i)=>{
    const b=document.createElement('button');
    b.className='swatch palette-builder-swatch'+(i===d.selectedIndex?' active':'');
    b.style.background=c;
    b.title='Click to edit this color';
    b.onclick=()=>{d.selectedIndex=i;renderPaletteEditorSlots();renderPaletteEditorControls();};
    box.appendChild(b);
  });
  if(d.colors.length<32){
    const add=document.createElement('button');
    add.className='swatch palette-builder-swatch palette-add-swatch';
    add.textContent='+';
    add.title='Add a light-purple color';
    add.onclick=()=>{d.colors.push(PALETTE_PLACEHOLDER_COLOR);d.selectedIndex=d.colors.length-1;renderPaletteEditorSlots();renderPaletteEditorControls();};
    box.appendChild(add);
  }
  if($('paletteBuilderCount'))$('paletteBuilderCount').textContent=`${d.colors.length}/32 colors`;
}
function renderPaletteEditorControls(){
  const color=selectedDraftColor(), p=hexToParts(color);
  const ci=$('peColorInput'); if(!ci)return;
  ci.value=color;
  [['R',p.r],['G',p.g],['B',p.b]].forEach(([ch,val])=>{
    const range=$('pe'+ch), num=$('pe'+ch+'N');
    range.value=val; num.value=val;
    const update=()=>{const r=Number($('peR').value),g=Number($('peG').value),b=Number($('peB').value);setDraftSelectedColor(partsToHex(r,g,b));};
    const updateNum=()=>{range.value=num.value;update();};
    range.oninput=()=>{num.value=range.value;update();};
    num.oninput=updateNum;
  });
  ci.oninput=()=>setDraftSelectedColor(ci.value);
  if($('peReplaceCurrent'))$('peReplaceCurrent').style.background=$('colorPicker').value;
}
function newPalette(){paletteEditorModal('Create')}
function editPalette(){const p=userPalette();if(!p)return alert('Built-in and Recent palettes cannot be edited. Create a custom palette first.');paletteEditorModal('Edit',p)}
