function renderFrames(){const el=$('framesList');el.innerHTML='';App.frames.forEach((f,i)=>{const d=document.createElement('div');d.className='frame-item'+(f.id===App.activeFrameId?' active':'');d.onclick=()=>loadFrame(f.id);d.ondblclick=()=>{const v=prompt('Rename frame:',f.name);if(v&&v.trim()){f.name=v.trim();renderFrames();refreshGhostControls();saveTab()}};const thumb=document.createElement('canvas');thumb.className='frame-thumb';thumb.width=84;thumb.height=64;thumb.dataset.frameId=f.id;const title=document.createElement('div');title.className='frame-title';title.textContent=f.name;const meta=document.createElement('div');meta.className='frame-meta';meta.textContent=`${i+1}/${App.frames.length}`;d.append(thumb,title,meta);el.appendChild(d)});renderFrameThumbs()}
function loadFrame(fid){if(App.selectionMode==='move')commitMove();saveFrame();const f=App.frames.find(f=>f.id===fid);if(!f)return;App.activeFrameId=f.id;App.layers=f.layers;App.activeLayerId=f.activeLayerId;App.layerCounter=f.layerCounter;App.selection=null;renderFrames();renderLayers();refreshGhostControls();draw();saveTab()}
function addFrame(){pushHistory('Add frame');saveFrame();App.frameCounter++;const f=frame('Frame '+App.frameCounter);App.frames.push(f);loadFrame(f.id)}
function dupFrame(){pushHistory('Duplicate frame');saveFrame();const cf=App.frames.find(f=>f.id===App.activeFrameId);App.frameCounter++;const nf=frame('Frame '+App.frameCounter,cf.layers);App.frames.splice(App.frames.findIndex(f=>f.id===App.activeFrameId)+1,0,nf);loadFrame(nf.id)}
function delFrame(){if(App.frames.length<=1)return alert('Need one frame.');confirmAction('Delete this frame?','This cannot be undone unless you use Undo right away.',()=>{pushHistory('Delete frame');const i=App.frames.findIndex(f=>f.id===App.activeFrameId);App.frames.splice(i,1);loadFrame(App.frames[Math.max(0,i-1)].id)})}
function stopPlay(){App.isPlaying=false;$('playBtn').textContent='Play';if(App.playbackTimer)clearInterval(App.playbackTimer);App.playbackTimer=null}
function play(){if(App.isPlaying){stopPlay();return}saveTab();App.isPlaying=true;$('playBtn').textContent='Stop';let i=App.frames.findIndex(f=>f.id===App.activeFrameId);const fps=Math.max(1,Math.min(30,Number($('fpsInput').value)||8));App.playbackTimer=setInterval(()=>{i=(i+1)%App.frames.length;const f=App.frames[i];App.activeFrameId=f.id;App.layers=f.layers;App.activeLayerId=f.activeLayerId;renderFrames();renderLayers();draw()},1000/fps)}
function addLayer(){pushHistory('Add layer');App.layerCounter++;const l=layer('Layer '+App.layerCounter);App.layers.unshift(l);App.activeLayerId=l.id;saveTab();renderLayers();refreshGhostControls();draw()}
function delLayer(){if(App.layers.length<=1)return alert('Need one layer.');confirmAction('Delete this layer?','This removes the active layer from this frame.',()=>{pushHistory('Delete layer');App.layers=App.layers.filter(l=>l.id!==App.activeLayerId);App.activeLayerId=App.layers[0].id;saveTab();renderLayers();refreshGhostControls();draw()})}
function mergeDown(){const i=App.layers.findIndex(l=>l.id===App.activeLayerId);if(i<0||i===App.layers.length-1)return alert('No layer beneath it.');pushHistory('Merge layer');const top=App.layers[i],bot=App.layers[i+1];for(let y=0;y<App.height;y++)for(let x=0;x<App.width;x++)if(top.pixels[y][x])bot.pixels[y][x]=top.pixels[y][x];App.layers.splice(i,1);App.activeLayerId=bot.id;saveTab();renderLayers();draw()}

// ===== V5 playback modes and drag timeline ordering =====
function syncPlaybackButtons(){
  if($('playDirectionBtn')) $('playDirectionBtn').textContent = App.playDirection === 'reverse' ? 'Reverse' : 'Forward';
  if($('playLoopBtn')) $('playLoopBtn').textContent = App.playMode === 'pingpong' ? 'Ping-Pong' : 'Loop';
}
function togglePlayDirection(){App.playDirection = App.playDirection === 'reverse' ? 'forward' : 'reverse'; syncPlaybackButtons(); saveTab();}
function togglePlayMode(){App.playMode = App.playMode === 'pingpong' ? 'loop' : 'pingpong'; syncPlaybackButtons(); saveTab();}
function reorderFrame(fromId,toId){
  if(!fromId||!toId||fromId===toId)return;
  pushHistory('Frame order');
  const from=App.frames.findIndex(f=>f.id===fromId),to=App.frames.findIndex(f=>f.id===toId);
  if(from<0||to<0)return;
  const [f]=App.frames.splice(from,1);App.frames.splice(to,0,f);
  saveTab();renderFrames();refreshGhostControls({redraw:true});
}
const __v5_renderFrames = renderFrames;
renderFrames = function(){
  __v5_renderFrames();
  document.querySelectorAll('.frame-item').forEach(d=>{
    const id=d.querySelector('canvas.frame-thumb')?.dataset.frameId;
    if(!id)return;
    d.draggable=true; d.dataset.frameId=id;
    d.ondragstart=e=>{e.dataTransfer.setData('text/plain',id);d.classList.add('dragging')};
    d.ondragend=()=>d.classList.remove('dragging');
    d.ondragover=e=>e.preventDefault();
    d.ondrop=e=>{e.preventDefault();reorderFrame(e.dataTransfer.getData('text/plain'),id)};
  });
};
function play(){
  if(App.isPlaying){stopPlay();return}
  saveTab();App.isPlaying=true;$('playBtn').textContent='Stop';
  let i=App.frames.findIndex(f=>f.id===App.activeFrameId);
  let dir=App.playDirection==='reverse'?-1:1;
  const fps=Math.max(1,Math.min(30,Number($('fpsInput').value)||8));
  App.playbackTimer=setInterval(()=>{
    if(App.playMode==='pingpong'){
      if(i+dir>=App.frames.length || i+dir<0) dir*=-1;
      i=Math.max(0,Math.min(App.frames.length-1,i+dir));
    }else{
      i=(i+dir+App.frames.length)%App.frames.length;
    }
    const f=App.frames[i];App.activeFrameId=f.id;App.layers=f.layers;App.activeLayerId=f.activeLayerId;renderFrames();renderLayers();draw();
  },1000/fps)
}
setTimeout(syncPlaybackButtons,0);
