function pos(e){const r=canvas.getBoundingClientRect();return{x:Math.floor((e.clientX-r.left)/App.pixelSize),y:Math.floor((e.clientY-r.top)/App.pixelSize)}}
function inCanvas(p){return p.x>=0&&p.y>=0&&p.x<App.width&&p.y<App.height}
function inSelection(p){
  if(!App.selection)return true;
  if(App.selectionCells)return App.selectionCells.has(p.x+','+p.y);
  return p.x>=App.selection.x&&p.x<App.selection.x+App.selection.w&&p.y>=App.selection.y&&p.y<App.selection.y+App.selection.h;
}
function norm(a,b){const x1=Math.max(0,Math.min(App.width-1,a.x)),y1=Math.max(0,Math.min(App.height-1,a.y)),x2=Math.max(0,Math.min(App.width-1,b.x)),y2=Math.max(0,Math.min(App.height-1,b.y));return{x:Math.min(x1,x2),y:Math.min(y1,y2),w:Math.abs(x2-x1)+1,h:Math.abs(y2-y1)+1,x2,y2}}
function inside(p){return App.selection&&p.x>=App.selection.x&&p.x<App.selection.x+App.selection.w&&p.y>=App.selection.y&&p.y<App.selection.y+App.selection.h}
function copy(l,a){return Array.from({length:a.h},(_,y)=>Array.from({length:a.w},(_,x)=>{
  const tx=a.x+x,ty=a.y+y;
  if(App.selectionCells&&!App.selectionCells.has(tx+','+ty))return null;
  return l.pixels[ty]?.[tx]||null;
}))}
function clearArea(l,a){
  if(App.selectionCells){App.selectionCells.forEach(k=>{const [x,y]=k.split(',').map(Number);if(l.pixels[y])l.pixels[y][x]=null});return}
  for(let y=0;y<a.h;y++)for(let x=0;x<a.w;x++)if(l.pixels[a.y+y])l.pixels[a.y+y][a.x+x]=null;
}
function paste(l,a,c){for(let y=0;y<a.h;y++)for(let x=0;x<a.w;x++){const tx=a.x+x,ty=a.y+y;if(tx>=0&&tx<App.width&&ty>=0&&ty<App.height&&c[y][x])l.pixels[ty][tx]=c[y][x]}}
function brushPoints(cx,cy){if(App.brushShape==='single'||App.brushSize<=1)return[[cx,cy]];const pts=[],r=Math.floor(App.brushSize/2);for(let y=-r;y<App.brushSize-r;y++)for(let x=-r;x<App.brushSize-r;x++){if(App.brushShape==='circle'){const dx=x+.5,dy=y+.5;if(Math.sqrt(dx*dx+dy*dy)>App.brushSize/2)continue}pts.push([cx+x,cy+y])}return pts}
function applyBrush(l,p,color){brushPoints(p.x,p.y).forEach(([x,y])=>{const pp={x,y};if(x>=0&&y>=0&&x<App.width&&y<App.height&&inSelection(pp))l.pixels[y][x]=color})}
function floodCells(l,x,y){const tc=l.pixels[y][x],st=[[x,y]],seen=new Set(),cells=[];while(st.length){const [cx,cy]=st.pop(),key=cx+','+cy;if(seen.has(key))continue;seen.add(key);if(cx<0||cy<0||cx>=App.width||cy>=App.height)continue;if(!inSelection({x:cx,y:cy}))continue;if(l.pixels[cy][cx]!==tc)continue;cells.push([cx,cy]);st.push([cx+1,cy],[cx-1,cy],[cx,cy+1],[cx,cy-1])}return cells}
function flood(l,x,y,nc){const tc=l.pixels[y][x];if(tc===nc)return;floodCells(l,x,y).forEach(([cx,cy])=>l.pixels[cy][cx]=nc)}
function hexToRgb(hex){return[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)]}
function mix(a,b,t){return a.map((v,i)=>Math.round(v+(b[i]-v)*t))}
function applyGradientFill(l,x,y){const cells=floodCells(l,x,y);if(!cells.length)return;const xs=cells.map(c=>c[0]),ys=cells.map(c=>c[1]);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);const a=hexToRgb($('colorPicker').value),b=hexToRgb(App.gradientColor||$('gradientColor').value),aa=App.currentAlpha,ba=App.gradientAlpha??1;cells.forEach(([cx,cy])=>{const t=App.gradientDirection==='vertical'?((cy-minY)/Math.max(1,maxY-minY)):((cx-minX)/Math.max(1,maxX-minX));const rgb=mix(a,b,t);const al=Math.round((aa+(ba-aa)*t)*100)/100;l.pixels[cy][cx]=`rgba(${rgb[0]}, ${rgb[1]}, ${rgb[2]}, ${al})`})}

function lassoBounds(points){
  const xs=points.map(q=>q.x),ys=points.map(q=>q.y);
  const minX=Math.max(0,Math.min(...xs)),maxX=Math.min(App.width-1,Math.max(...xs));
  const minY=Math.max(0,Math.min(...ys)),maxY=Math.min(App.height-1,Math.max(...ys));
  return {x:minX,y:minY,w:maxX-minX+1,h:maxY-minY+1};
}
function pointInPoly(x,y,pts){
  let inside=false,px=x+.5,py=y+.5;
  for(let i=0,j=pts.length-1;i<pts.length;j=i++){
    const xi=pts[i].x+.5,yi=pts[i].y+.5,xj=pts[j].x+.5,yj=pts[j].y+.5;
    const hit=((yi>py)!==(yj>py))&&(px<(xj-xi)*(py-yi)/(yj-yi+0.000001)+xi);
    if(hit)inside=!inside;
  }
  return inside;
}
function makeFreehandSelection(points){
  if(!points||points.length<3)return;
  const b=lassoBounds(points),cells=new Set();
  for(let y=b.y;y<b.y+b.h;y++)for(let x=b.x;x<b.x+b.w;x++){
    if(pointInPoly(x,y,points))cells.add(x+','+y);
  }
  if(!cells.size)return;
  App.selection=b;App.selectionCells=cells;
}

function commitMove(){const l=getActiveLayer();if(App.selectionMode==='move'&&l&&App.selectedPixels){paste(l,App.selection,App.selectedPixels);App.selectionMode=null;App.selectedPixels=null;App.moveOriginal=null;App.moveOriginalCells=null;saveTab();draw();updateSelectionUI();return}draw();updateSelectionUI()}
function cancelMove(){const l=getActiveLayer();if(App.selectionMode==='move'&&l&&App.selectedPixels&&App.moveOriginal){paste(l,App.moveOriginal,App.selectedPixels)}App.selection=App.moveOriginal||App.selection;App.selectionCells=App.moveOriginalCells||App.selectionCells;App.selectionMode=null;App.selectedPixels=null;App.moveOriginal=null;App.moveOriginalCells=null;App.moveOriginalCells=null;saveTab();draw();updateSelectionUI()}
function magicSelect(l,p){const cells=floodCells(l,p.x,p.y);if(!cells.length)return;const xs=cells.map(c=>c[0]),ys=cells.map(c=>c[1]);App.selection={x:Math.min(...xs),y:Math.min(...ys),w:Math.max(...xs)-Math.min(...xs)+1,h:Math.max(...ys)-Math.min(...ys)+1};App.selectionCells=new Set(cells.map(c=>c.join(',')));saveTab();draw();updateSelectionUI()}
function selectStart(e){const l=getActiveLayer(),p=pos(e);if(!l||!inCanvas(p))return;App.selectionStart=p;if(App.selectMode==='magic'&&!inside(p)){magicSelect(l,p);return}if(inside(p)){pushHistory('Move selection');App.selectionMode='move';App.selectedPixels=copy(l,App.selection);App.moveOriginal={...App.selection};App.moveOriginalCells=App.selectionCells?new Set(App.selectionCells):null;clearArea(l,App.selection);App.moveOffset={x:p.x-App.selection.x,y:p.y-App.selection.y}}else{App.selectionMode='new';App.selection={x:p.x,y:p.y,w:1,h:1};App.selectionCells=null;App.selectedPixels=null;App.moveOriginal=null;App.moveOriginalCells=null;App.lassoPoints=(App.selectMode==='boxlasso'||App.selectMode==='freelasso')?[p]:null}draw();updateSelectionUI()}
function selectMove(e){if(!App.selectionMode)return;const p=pos(e);if(App.selectionMode==='new'){
    if(App.selectMode==='boxlasso'||App.selectMode==='freelasso'){
      App.lassoPoints.push(p);
      App.selection=lassoBounds(App.lassoPoints);
      if(App.selectMode==='freelasso')makeFreehandSelection(App.lassoPoints);
    }else App.selection=norm(App.selectionStart,p);
  }else{
    const nx=Math.max(0,Math.min(App.width-App.selection.w,p.x-App.moveOffset.x));
    const ny=Math.max(0,Math.min(App.height-App.selection.h,p.y-App.moveOffset.y));
    if(App.selectionCells&&App.moveOriginalCells){
      const dx=nx-App.moveOriginal.x,dy=ny-App.moveOriginal.y;
      App.selectionCells=new Set([...App.moveOriginalCells].map(k=>{const [x,y]=k.split(',').map(Number);return (x+dx)+','+(y+dy)}).filter(k=>{const [x,y]=k.split(',').map(Number);return x>=0&&y>=0&&x<App.width&&y<App.height}));
    }
    App.selection.x=nx;App.selection.y=ny;
  }draw();updateSelectionUI()}
function selectEnd(){
  if(App.selectionMode==='move')commitMove();
  else{
    if(App.selectMode==='freelasso'&&App.lassoPoints)makeFreehandSelection(App.lassoPoints);
    if(App.selectMode==='boxlasso')App.selectionCells=null;
    App.selectionMode=null;App.selectionStart=null;App.lassoPoints=null;saveTab();draw();updateSelectionUI()
  }
}
function clearSel(){if(App.selectionMode==='move')commitMove();App.selection=null;App.selectionMode=null;App.selectedPixels=null;App.selectionStart=null;App.moveOriginal=null;App.moveOriginalCells=null;App.selectionCells=null;saveTab();draw();updateSelectionUI()}
function delSel(){confirmAction('Delete selected pixels?','This clears pixels inside the current selection on the active layer.',()=>{const l=getActiveLayer();if(l&&App.selection){pushHistory('Delete selection');clearArea(l,App.selection);clearSel();saveTab()}})}
function pickColorAt(p){for(let i=0;i<App.layers.length;i++){const l=App.layers[i];if(!l.visible)continue;const c=l.pixels[p.y]?.[p.x];if(c){parseColor(c,App.dropperMaintainAlpha);remember(c);setTool('draw');return}}}
function shapeCells(a){const cells=[],seen=new Set();const add=(x,y)=>{if(x>=0&&y>=0&&x<App.width&&y<App.height&&inSelection({x,y})){const k=x+','+y;if(!seen.has(k)){seen.add(k);cells.push([x,y])}}};const x0=a.x,y0=a.y,x1=a.x2,y1=a.y2;if(App.shapeType==='line'){let dx=Math.abs(x1-x0),sx=x0<x1?1:-1,dy=-Math.abs(y1-y0),sy=y0<y1?1:-1,err=dx+dy,x=x0,y=y0;while(true){brushPoints(x,y).forEach(([bx,by])=>add(bx,by));if(x===x1&&y===y1)break;let e2=2*err;if(e2>=dy){err+=dy;x+=sx}if(e2<=dx){err+=dx;y+=sy}}return cells}for(let y=a.y;y<a.y+a.h;y++)for(let x=a.x;x<a.x+a.w;x++){const border=x<a.x+App.brushSize||x>=a.x+a.w-App.brushSize||y<a.y+App.brushSize||y>=a.y+a.h-App.brushSize;if(App.shapeType==='rect'){if(App.shapeFilled||border)add(x,y)}else{const rx=Math.max(.5,a.w/2),ry=Math.max(.5,a.h/2),cx=a.x+rx-.5,cy=a.y+ry-.5;const v=((x-cx)**2)/(rx*rx)+((y-cy)**2)/(ry*ry);const innerRx=Math.max(0,rx-App.brushSize),innerRy=Math.max(0,ry-App.brushSize);const inner=innerRx&&innerRy?((x-cx)**2)/(innerRx*innerRx)+((y-cy)**2)/(innerRy*innerRy):99;if(App.shapeFilled?v<=1:(v<=1&&inner>=1))add(x,y)}}return cells}
function shapeRaster(l,a,color){shapeCells(a).forEach(([x,y])=>l.pixels[y][x]=color)}
function paint(e){if(App.currentTool==='select'){selectStart(e);return}const l=getActiveLayer(),p=pos(e);if(!l||!l.visible||!inCanvas(p))return;if(App.currentTool==='dropper'){pickColorAt(p);return}if(App.currentTool==='fill'){pushHistory('Fill');if(App.fillMode==='gradient')applyGradientFill(l,p.x,p.y);else{const c=paintColor();flood(l,p.x,p.y,c);remember(c)}saveTab();draw();return}if(App.currentTool==='shape'){pushHistory('Shape');App.shapeStart=p;App.shapePreview={x:p.x,y:p.y,w:1,h:1,x2:p.x,y2:p.y};draw();return}if(!App.strokeActive){pushHistory(App.currentTool==='draw'?'Draw':'Erase');App.strokeActive=true}const c=paintColor();applyBrush(l,p,App.currentTool==='draw'?c:null);if(App.currentTool==='draw')remember(c);saveTab();draw()}
function dragPaint(e){if(App.currentTool==='select'){selectMove(e);return}if(App.currentTool==='shape'&&App.shapeStart){const p=pos(e);App.shapePreview=App.shapeType==='line'?{x:App.shapeStart.x,y:App.shapeStart.y,w:1,h:1,x2:Math.max(0,Math.min(App.width-1,p.x)),y2:Math.max(0,Math.min(App.height-1,p.y))}:norm(App.shapeStart,p);draw();return}if(App.currentTool!=='fill'&&App.currentTool!=='dropper')paint(e)}
function endPaint(){if(App.currentTool==='select')selectEnd();if(App.currentTool==='shape'&&App.shapePreview){const l=getActiveLayer();shapeRaster(l,App.shapePreview,paintColor());remember(paintColor());App.shapeStart=null;App.shapePreview=null;saveTab();draw()}App.strokeActive=false;updateHistoryButtons();updateSelectionUI()}
function setTool(t){if(App.selectionMode==='move')commitMove();const same=App.currentTool===t,settings=$('toolSettings'),wasOpen=!settings.classList.contains('hidden');App.currentTool=t;document.querySelectorAll('.tool').forEach(b=>b.classList.remove('active'));document.querySelector(`[data-tool="${t}"]`)?.classList.add('active');['brushOptions','selectOptions','fillOptions','dropperOptions','shapeOptions'].forEach(id=>$(id)?.classList.add('hidden'));if(['draw','erase'].includes(t))$('brushOptions').classList.remove('hidden');if(t==='select')$('selectOptions').classList.remove('hidden');if(t==='fill'){$('fillOptions').classList.remove('hidden');$('gradientOptions').classList.toggle('hidden',App.fillMode!=='gradient')}if(t==='dropper')$('dropperOptions').classList.remove('hidden');if(t==='shape'){$('brushOptions').classList.remove('hidden');$('shapeOptions').classList.remove('hidden')}settings.classList.toggle('hidden',same&&wasOpen)}

// ===== V5 tool dropdown behavior and selection shortcut =====
function setTool(t){
  if(App.selectionMode==='move')commitMove();
  const same=App.currentTool===t;
  const settings=$('toolSettings');
  const wasOpen=!settings.classList.contains('hidden');
  App.currentTool=t;
  document.querySelectorAll('.tool').forEach(b=>b.classList.remove('active'));
  document.querySelector(`[data-tool="${t}"]`)?.classList.add('active');
  ['brushOptions','selectOptions','fillOptions','dropperOptions','shapeOptions'].forEach(id=>$(id)?.classList.add('hidden'));
  if(['draw','erase'].includes(t))$('brushOptions').classList.remove('hidden');
  if(t==='select')$('selectOptions').classList.remove('hidden');
  if(t==='fill'){$('fillOptions').classList.remove('hidden');$('gradientOptions').classList.toggle('hidden',App.fillMode!=='gradient')}
  if(t==='dropper')$('dropperOptions').classList.remove('hidden');
  if(t==='shape'){$('brushOptions').classList.remove('hidden');$('shapeOptions').classList.remove('hidden')}
  // First click only selects the tool. Second click toggles that tool's dropdown.
  if(!same) settings.classList.add('hidden');
  else settings.classList.toggle('hidden', wasOpen);
}
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&App.selection)clearSel()});
