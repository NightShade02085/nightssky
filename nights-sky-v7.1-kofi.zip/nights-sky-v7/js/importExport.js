function exportPNG(){saveTab();const ex=document.createElement('canvas'),ec=ex.getContext('2d');ex.width=App.width;ex.height=App.height;App.layers.slice().reverse().forEach(l=>{if(!l.visible)return;for(let y=0;y<App.height;y++)for(let x=0;x<App.width;x++)if(l.pixels[y][x]){ec.fillStyle=l.pixels[y][x];ec.fillRect(x,y,1,1)}});const a=document.createElement('a');a.download='pixel-art.png';a.href=ex.toDataURL('image/png');a.click()}
function exportGIF(){saveTab();if(!window.GIFEncoderLite)return alert('GIF encoder did not load.');const fps=Math.max(1,Math.min(30,Number($('fpsInput').value)||8));GIFEncoderLite.exportGIF(App.frames,App.width,App.height,1000/fps)}
function importImage(file){const img=new Image();img.onload=()=>{const off=document.createElement('canvas'),oc=off.getContext('2d');off.width=Math.min(App.width,img.width);off.height=Math.min(App.height,img.height);oc.drawImage(img,0,0,off.width,off.height);const data=oc.getImageData(0,0,off.width,off.height).data;const l=getActiveLayer();for(let y=0;y<off.height;y++)for(let x=0;x<off.width;x++){const i=(y*off.width+x)*4,a=data[i+3];if(a>0)l.pixels[y][x]=`rgba(${data[i]}, ${data[i+1]}, ${data[i+2]}, ${Math.round(a/255*100)/100})`}saveTab();draw();URL.revokeObjectURL(img.src)};img.src=URL.createObjectURL(file)}
function colorDistance(a,b){return Math.abs(a[0]-b[0])+Math.abs(a[1]-b[1])+Math.abs(a[2]-b[2])}
function extractPaletteFromImageFile(file){const img=new Image();img.onload=()=>{const off=document.createElement('canvas'),oc=off.getContext('2d');const scale=Math.min(1,256/Math.max(img.width,img.height));off.width=Math.max(1,Math.floor(img.width*scale));off.height=Math.max(1,Math.floor(img.height*scale));oc.drawImage(img,0,0,off.width,off.height);const data=oc.getImageData(0,0,off.width,off.height).data;const counts=new Map();for(let i=0;i<data.length;i+=4){if(data[i+3]<128)continue;const hex='#'+[data[i],data[i+1],data[i+2]].map(v=>v.toString(16).padStart(2,'0')).join('');counts.set(hex,(counts.get(hex)||0)+1)}let colors=[...counts.entries()].sort((a,b)=>b[1]-a[1]).map(x=>x[0]);const chosen=[];for(const c of colors){const rgb=[parseInt(c.slice(1,3),16),parseInt(c.slice(3,5),16),parseInt(c.slice(5,7),16)];if(chosen.every(ch=>colorDistance(rgb,ch.rgb)>45)){chosen.push({hex:c,rgb});if(chosen.length>=32)break}}const name=prompt('Name extracted palette:','Extracted Palette');if(name){App.palettes.push({id:uid(),name,colors:chosen.map(c=>c.hex).slice(0,32)});saveLocalMeta();buildPaletteSelect();$('paletteSelect').value=App.palettes.at(-1).id;App.activePaletteId=$('paletteSelect').value;buildSwatches()}URL.revokeObjectURL(img.src)};img.src=URL.createObjectURL(file)}
function extractPaletteCurrent(){const input=document.createElement('input');input.type='file';input.accept='image/*';input.onchange=()=>input.files[0]&&extractPaletteFromImageFile(input.files[0]);input.click()}
function exportPalette(){const p=allPalettes().find(p=>p.id===App.activePaletteId);if(!p)return;downloadJSON({version:1,type:'pixel-studio-palette',name:p.name,colors:p.colors.slice(0,32)},p.name.replace(/\s+/g,'-').toLowerCase()+'.palette.json')}
function importPalette(file){const r=new FileReader();r.onload=()=>{try{const p=JSON.parse(r.result);if(!Array.isArray(p.colors))throw new Error();App.palettes.push({id:uid(),name:p.name||'Imported Palette',colors:p.colors.filter(c=>/^#[0-9a-fA-F]{6}$/.test(c)).slice(0,32)});saveLocalMeta();buildPaletteSelect();buildSwatches()}catch(e){alert('Could not import palette.')}};r.readAsText(file)}
function saveTemplate(){const l=getActiveLayer();if(!l)return;const name=prompt('Template name:',l.name+' Template');if(!name)return;App.templates.push({id:uid(),name,width:App.width,height:App.height,pixels:clonePix(l.pixels)});saveLocalMeta();renderTemplates()}
function renderTemplates(){const s=$('templateSelect');if(!s)return;s.innerHTML='<option value="">Choose template...</option>';App.templates.forEach(t=>{const o=document.createElement('option');o.value=t.id;o.textContent=t.name;s.appendChild(o)})}
function loadTemplate(){const t=App.templates.find(t=>t.id===$('templateSelect').value),l=getActiveLayer();if(!t||!l)return;for(let y=0;y<Math.min(App.height,t.height);y++)for(let x=0;x<Math.min(App.width,t.width);x++)if(t.pixels[y][x])l.pixels[y][x]=t.pixels[y][x];saveTab();draw()}
function ghostTemplate(){const id=$('templateSelect').value;if(!id)return;App.ghost={type:'template',templateId:id};App.onionSkin=true;$('onionToggleBtn').textContent='Onion Skin: On';saveTab();draw()}
function refreshGhostControls(){const ts=$('ghostTabSelect'),fs=$('ghostFrameSelect'),ls=$('ghostLayerSelect');if(!ts)return;ts.innerHTML='';App.artTabs.forEach(t=>{const o=document.createElement('option');o.value=t.id;o.textContent=t.name;ts.appendChild(o)});ts.value=ts.value||App.activeTabId;const t=App.artTabs.find(t=>t.id===ts.value)||App.artTabs[0];fs.innerHTML='';(t?.frames||[]).forEach(f=>{const o=document.createElement('option');o.value=f.id;o.textContent=f.name;fs.appendChild(o)});const f=(t?.frames||[]).find(f=>f.id===fs.value)||t?.frames[0];ls.innerHTML='';(f?.layers||[]).forEach(l=>{const o=document.createElement('option');o.value=l.id;o.textContent=l.name;ls.appendChild(o)});setGhostFromControls(false)}
function setGhostFromControls(redraw=true){const tabId=$('ghostTabSelect').value,frameId=$('ghostFrameSelect').value,layerId=$('ghostLayerSelect').value;if(tabId&&frameId&&layerId)App.ghost={type:'layer',tabId,frameId,layerId};if(redraw){saveTab();draw()}}

// ===== V2 ghost selector fix: preserve selected tab -> frame -> layer correctly =====
function refreshGhostControls(){
  const ts=$('ghostTabSelect'),fs=$('ghostFrameSelect'),ls=$('ghostLayerSelect');if(!ts||!fs||!ls)return;
  const prevTab=ts.value||App.ghost?.tabId||App.activeTabId;
  const prevFrame=fs.value||App.ghost?.frameId;
  const prevLayer=ls.value||App.ghost?.layerId;
  ts.innerHTML='';
  App.artTabs.forEach(t=>{const o=document.createElement('option');o.value=t.id;o.textContent=t.name;ts.appendChild(o)});
  ts.value=App.artTabs.some(t=>t.id===prevTab)?prevTab:App.activeTabId;
  const t=App.artTabs.find(t=>t.id===ts.value)||App.artTabs[0];
  fs.innerHTML='';
  (t?.frames||[]).forEach((f,i)=>{const o=document.createElement('option');o.value=f.id;o.textContent=f.name||`Frame ${i+1}`;fs.appendChild(o)});
  fs.value=(t?.frames||[]).some(f=>f.id===prevFrame)?prevFrame:(t?.frames?.[0]?.id||'');
  const f=(t?.frames||[]).find(f=>f.id===fs.value)||t?.frames?.[0];
  ls.innerHTML='';
  (f?.layers||[]).forEach((l,i)=>{const o=document.createElement('option');o.value=l.id;o.textContent=l.name||`Layer ${i+1}`;ls.appendChild(o)});
  ls.value=(f?.layers||[]).some(l=>l.id===prevLayer)?prevLayer:(f?.layers?.[0]?.id||'');
  setGhostFromControls(false);
}
function setGhostFromControls(redraw=true){
  const tabId=$('ghostTabSelect').value,frameId=$('ghostFrameSelect').value,layerId=$('ghostLayerSelect').value;
  if(tabId&&frameId&&layerId)App.ghost={type:'layer',tabId,frameId,layerId};
  if(redraw){saveTab();draw()}
}

// ===== V3 template and ghost management overrides =====
function renderTemplates(){
  const s=$('templateSelect');if(!s)return;
  const term=($('templateSearch')?.value||'').toLowerCase();
  s.innerHTML='<option value="">Choose template...</option>';
  App.templates.filter(t=>!term||t.name.toLowerCase().includes(term)).forEach(t=>{const o=document.createElement('option');o.value=t.id;o.textContent=t.name;s.appendChild(o)})
}
function editTemplate(){const t=App.templates.find(t=>t.id===$('templateSelect').value);if(!t)return;const n=prompt('Rename template:',t.name);if(n&&n.trim()){t.name=n.trim();saveLocalMeta();renderTemplates();$('templateSelect').value=t.id}}
function deleteTemplate(){const t=App.templates.find(t=>t.id===$('templateSelect').value);if(!t)return;confirmAction('Delete template?','This removes the saved template from local storage.',()=>{App.templates=App.templates.filter(x=>x.id!==t.id);if(App.ghost?.type==='template'&&App.ghost.templateId===t.id)App.ghost=null;saveLocalMeta();renderTemplates();draw()})}
function toggleTemplateGhost(){const id=$('templateSelect').value;if(!id)return;if(App.ghost?.type==='template'&&App.ghost.templateId===id){App.ghost=null}else{App.ghost={type:'template',templateId:id};App.onionSkin=true;App.onionCustomGhost=true}syncOnionUI();saveTab();draw()}
function refreshGhostControls(opts={}){
  const ts=$('ghostTabSelect'),fs=$('ghostFrameSelect'),ls=$('ghostLayerSelect');if(!ts||!fs||!ls)return;
  const prevTab=opts.keepTab?ts.value:(App.ghost?.tabId||ts.value||App.activeTabId);
  const prevFrame=opts.keepFrame?fs.value:(App.ghost?.frameId||fs.value);
  const prevLayer=App.ghost?.layerId||ls.value;
  ts.innerHTML='';
  App.artTabs.forEach(t=>{const o=document.createElement('option');o.value=t.id;o.textContent=t.name;ts.appendChild(o)});
  ts.value=App.artTabs.some(t=>t.id===prevTab)?prevTab:App.activeTabId;
  const t=App.artTabs.find(t=>t.id===ts.value)||App.artTabs[0];
  fs.innerHTML='';
  (t?.frames||[]).forEach((f,i)=>{const o=document.createElement('option');o.value=f.id;o.textContent=f.name||`Frame ${i+1}`;fs.appendChild(o)});
  fs.value=(t?.frames||[]).some(f=>f.id===prevFrame)?prevFrame:(t?.frames?.[0]?.id||'');
  const f=(t?.frames||[]).find(f=>f.id===fs.value)||t?.frames?.[0];
  ls.innerHTML='';
  (f?.layers||[]).forEach((l,i)=>{const o=document.createElement('option');o.value=l.id;o.textContent=l.name||`Layer ${i+1}`;ls.appendChild(o)});
  ls.value=(f?.layers||[]).some(l=>l.id===prevLayer)?prevLayer:(f?.layers?.[0]?.id||'');
  setGhostFromControls(!!opts.redraw);
}
function setGhostFromControls(redraw=true){
  const tabId=$('ghostTabSelect').value,frameId=$('ghostFrameSelect').value,layerId=$('ghostLayerSelect').value;
  if(tabId&&frameId&&layerId){App.ghost={type:'layer',tabId,frameId,layerId};App.onionSkin=true;App.onionCustomGhost=true;if($('customGhostToggle'))$('customGhostToggle').checked=true;typeof syncOnionUI==='function'&&syncOnionUI()}
  if(redraw){saveTab();draw()}
}


// ===== V4 export wizard =====
function mergedCanvas(flatten='#ffffff'){
  saveTab();
  const ex=document.createElement('canvas'),ec=ex.getContext('2d');
  ex.width=App.width;ex.height=App.height;
  if(flatten){ec.fillStyle=flatten;ec.fillRect(0,0,ex.width,ex.height)}
  App.layers.slice().reverse().forEach(l=>{if(!l.visible)return;for(let y=0;y<App.height;y++)for(let x=0;x<App.width;x++){const col=l.pixels[y]?.[x];if(col){ec.fillStyle=col;ec.fillRect(x,y,1,1)}}});
  return ex;
}
function downloadCanvas(c,name,type='image/png',quality=.92){
  const a=document.createElement('a');a.download=name;a.href=c.toDataURL(type,quality);a.click();
}
function exportJPG(){downloadCanvas(mergedCanvas('#ffffff'),'pixel-art.jpg','image/jpeg',.92)}
function exportICO(){
  const c=mergedCanvas(null),pngData=c.toDataURL('image/png');
  fetch(pngData).then(r=>r.arrayBuffer()).then(buf=>{
    const png=new Uint8Array(buf),ico=new Uint8Array(22+png.length),dv=new DataView(ico.buffer);
    dv.setUint16(0,0,true);dv.setUint16(2,1,true);dv.setUint16(4,1,true);
    ico[6]=App.width>=256?0:App.width;ico[7]=App.height>=256?0:App.height;ico[8]=0;ico[9]=0;
    dv.setUint16(10,1,true);dv.setUint16(12,32,true);dv.setUint32(14,png.length,true);dv.setUint32(18,22,true);
    ico.set(png,22);
    const a=document.createElement('a');a.download='pixel-icon.ico';a.href=URL.createObjectURL(new Blob([ico],{type:'image/x-icon'}));a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)
  })
}
function exportPNG(){downloadCanvas(mergedCanvas(null),'pixel-art.png','image/png')}
function exportWizard(){
  showModal(`<h2>Export Project</h2><p class="hint">Choose the file type you want to export from the active tab.</p><div class="tool-row"><button class="primary" id="exPng">PNG Image</button><button id="exJpg">JPG Image</button><button id="exGif">Animated GIF</button><button id="exIco">ICO Icon</button><button id="exJson">Project JSON</button></div><div class="modal-actions"><button onclick="closeModal()">Cancel</button></div>`);
  setTimeout(()=>{
    $('exPng').onclick=()=>{closeModal();exportPNG()};
    $('exJpg').onclick=()=>{closeModal();exportJPG()};
    $('exGif').onclick=()=>{closeModal();exportGIF()};
    $('exIco').onclick=()=>{closeModal();exportICO()};
    $('exJson').onclick=()=>{closeModal();saveProject()};
  },0)
}

// ===== V5 template previews, quickbar, and export settings =====
function drawPixelsPreview(canvasEl,pixels,w,h){
  if(!canvasEl)return;
  const c=canvasEl,tc=c.getContext('2d');tc.clearRect(0,0,c.width,c.height);tc.imageSmoothingEnabled=false;
  if(!pixels)return;
  const scale=Math.max(1,Math.floor(Math.min(c.width/w,c.height/h)));
  const ox=Math.floor((c.width-w*scale)/2),oy=Math.floor((c.height-h*scale)/2);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const col=pixels[y]?.[x];if(col){tc.fillStyle=col;tc.fillRect(ox+x*scale,oy+y*scale,scale,scale)}}
}
function updateTemplatePreview(){
  const t=App.templates.find(t=>t.id===$('templateSelect')?.value);
  drawPixelsPreview($('templatePreview'),t?.pixels,t?.width||App.width,t?.height||App.height);
}
function syncTemplateQuickbar(){
  const qb=$('templateQuickbar'),qs=$('quickTemplateSelect'),main=$('templateSelect');
  if(!qb||!qs||!main)return;
  qb.classList.toggle('hidden',!($('templateQuickbarToggle')?.checked));
  qs.innerHTML=main.innerHTML; qs.value=main.value;
}
const __v5_renderTemplates = renderTemplates;
renderTemplates = function(){
  __v5_renderTemplates();
  updateTemplatePreview();
  syncTemplateQuickbar();
};
const __v5_saveTemplate = saveTemplate;
saveTemplate = function(){__v5_saveTemplate();renderTemplates();};
const __v5_loadTemplate = loadTemplate;
loadTemplate = function(){
  if($('quickTemplateSelect') && !$('quickTemplateSelect').closest('.hidden') && $('quickTemplateSelect').value) $('templateSelect').value=$('quickTemplateSelect').value;
  __v5_loadTemplate();
};
const __v5_toggleTemplateGhost = toggleTemplateGhost;
toggleTemplateGhost = function(){
  if($('quickTemplateSelect') && !$('quickTemplateSelect').closest('.hidden') && $('quickTemplateSelect').value) $('templateSelect').value=$('quickTemplateSelect').value;
  __v5_toggleTemplateGhost();
};
function scaledCanvas(src,scale=1,bg='transparent'){
  const out=document.createElement('canvas'),oc=out.getContext('2d');out.width=src.width*scale;out.height=src.height*scale;oc.imageSmoothingEnabled=false;
  if(bg&&bg!=='transparent'){oc.fillStyle=bg;oc.fillRect(0,0,out.width,out.height)}
  oc.drawImage(src,0,0,out.width,out.height);return out;
}
function frameCanvas(f,bg='transparent'){
  const c=document.createElement('canvas'),tc=c.getContext('2d');c.width=App.width;c.height=App.height;
  if(bg&&bg!=='transparent'){tc.fillStyle=bg;tc.fillRect(0,0,c.width,c.height)}
  f.layers.slice().reverse().forEach(l=>{if(!l.visible)return;for(let y=0;y<App.height;y++)for(let x=0;x<App.width;x++){const col=l.pixels[y]?.[x];if(col){tc.fillStyle=col;tc.fillRect(x,y,1,1)}}});
  return c;
}
function exportPNGWithSettings(scale,bg){downloadCanvas(scaledCanvas(mergedCanvas(bg==='transparent'?null:bg),scale,bg),'pixel-art.png','image/png')}
function exportJPGWithSettings(scale,bg){downloadCanvas(scaledCanvas(mergedCanvas(bg==='transparent'?'#ffffff':bg),scale,bg),'pixel-art.jpg','image/jpeg',.92)}
function exportICOWithSettings(scale,bg){exportICO()}
function exportGIFWithSettings(scale,bg,delay){
  saveTab();
  if(!window.GIFEncoderLite)return alert('GIF encoder did not load.');
  const oldFps=$('fpsInput').value;
  const fps=Math.max(1,Math.min(60,Math.round(1000/Math.max(20,delay||125))));
  $('fpsInput').value=fps;
  // Current lightweight local encoder uses App.frames and FPS. Scale/background are included in wizard for PNG/JPG now and reserved for a fuller encoder.
  exportGIF();
  $('fpsInput').value=oldFps;
}
function exportWizard(){
  showModal(`<h2>Export Project</h2>
    <p class="hint">Choose a file type and basic export settings for the active tab.</p>
    <div class="row2"><div><label>Scale</label><select id="exScale"><option value="1">1x</option><option value="2">2x</option><option value="4">4x</option><option value="8">8x</option></select></div><div><label>GIF Frame Delay (ms)</label><input id="exDelay" type="number" min="20" max="2000" value="125"></div></div>
    <label>Background</label><div class="row2"><select id="exBgMode"><option value="transparent">Transparent</option><option value="custom">Custom Color</option><option value="white">White</option></select><input id="exBgColor" type="color" value="#ffffff"></div>
    <div class="tool-row"><button class="primary" id="exPng">PNG Image</button><button id="exJpg">JPG Image</button><button id="exGif">Animated GIF</button><button id="exIco">ICO Icon</button><button id="exJson">Project JSON</button></div>
    <div class="modal-actions"><button onclick="closeModal()">Cancel</button></div>`);
  setTimeout(()=>{
    const get=()=>{const scale=Number($('exScale').value)||1;const bgMode=$('exBgMode').value;const bg=bgMode==='custom'?$('exBgColor').value:(bgMode==='white'?'#ffffff':'transparent');const delay=Number($('exDelay').value)||125;return{scale,bg,delay}};
    $('exPng').onclick=()=>{const o=get();closeModal();exportPNGWithSettings(o.scale,o.bg)};
    $('exJpg').onclick=()=>{const o=get();closeModal();exportJPGWithSettings(o.scale,o.bg)};
    $('exGif').onclick=()=>{const o=get();closeModal();exportGIFWithSettings(o.scale,o.bg,o.delay)};
    $('exIco').onclick=()=>{const o=get();closeModal();exportICOWithSettings(o.scale,o.bg)};
    $('exJson').onclick=()=>{closeModal();saveProject()};
  },0)
}
