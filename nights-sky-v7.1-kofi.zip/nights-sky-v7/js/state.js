const $=id=>document.getElementById(id);
const App={gridSize:32,width:32,height:32,pixelSize:18,currentTool:'draw',currentAlpha:1,brushSize:1,brushShape:'single',shapeType:'rect',shapeFilled:false,showGrid:true,isDrawing:false,artTabs:[],activeTabId:null,tabCounter:0,frames:[],activeFrameId:null,frameCounter:1,layers:[],activeLayerId:null,layerCounter:1,isPlaying:false,playbackTimer:null,onionSkin:false,onionOpacity:.35,ghost:null,selection:null,selectionStart:null,selectionMode:null,selectedPixels:null,moveOffset:{x:0,y:0},shapeStart:null,shapePreview:null,recent:[],palettes:[],activePaletteId:'quick',templates:[],gridColor:'#000000',selectMode:'rect',fillMode:'solid',gradientColor:'#ffffff',gradientAlpha:1,gradientDirection:'horizontal',dropperMaintainAlpha:false,onionPrevNext:true,onionCustomGhost:true,projectsDirHandle:null,selectionCells:null,lassoPoints:null,playDirection:'forward',playMode:'loop',templateQuickbar:false};
function uid(){return crypto.randomUUID?crypto.randomUUID():String(Date.now()+Math.random())}
function pix(w=App.width,h=App.height){return Array.from({length:h},()=>Array(w).fill(null))}
function layer(name,w=App.width,h=App.height){return{id:uid(),name,visible:true,pixels:pix(w,h)}}
function clonePix(p){return p.map(r=>[...r])}
function cloneLayers(ls){return ls.map(l=>({id:uid(),name:l.name,visible:l.visible,pixels:clonePix(l.pixels)}))}
function frame(name,src=null){const ls=src?cloneLayers(src):[layer('Layer 1')];return{id:uid(),name,layers:ls,activeLayerId:ls[0].id,layerCounter:ls.length}}
function getActiveLayer(){return App.layers.find(l=>l.id===App.activeLayerId)}
function saveFrame(){const f=App.frames.find(f=>f.id===App.activeFrameId);if(!f)return;f.layers=App.layers;f.activeLayerId=App.activeLayerId;f.layerCounter=App.layerCounter}
function saveTab(){if(!App.activeTabId)return;saveFrame();const t=App.artTabs.find(t=>t.id===App.activeTabId);if(!t)return;Object.assign(t,{width:App.width,height:App.height,gridSize:App.width,pixelSize:App.pixelSize,frames:App.frames,activeFrameId:App.activeFrameId,frameCounter:App.frameCounter,layers:App.layers,activeLayerId:App.activeLayerId,layerCounter:App.layerCounter,selection:App.selection,selectionCells:App.selectionCells?[...App.selectionCells]:null,ghost:App.ghost,gridColor:App.gridColor,onionSkin:App.onionSkin,onionOpacity:App.onionOpacity,onionPrevNext:App.onionPrevNext,onionCustomGhost:App.onionCustomGhost})}
function createTab(name,w,h,showTimeline=true,paletteId='quick'){const old={w:App.width,h:App.height};App.width=w;App.height=h;const f=frame('Frame 1');App.width=old.w;App.height=old.h;return{id:uid(),name,width:w,height:h,gridSize:w,pixelSize:App.pixelSize,frames:[f],activeFrameId:f.id,frameCounter:1,layers:f.layers,activeLayerId:f.activeLayerId,layerCounter:1,selection:null,selectionCells:null,ghost:null,showTimeline,paletteId,gridColor:App.gridColor,onionSkin:false,onionOpacity:.35,onionPrevNext:true,onionCustomGhost:true}}

// ===== V2 history helpers =====
function snapshotCurrent(){
  saveFrame();
  return JSON.stringify({
    width:App.width,height:App.height,frames:App.frames,activeFrameId:App.activeFrameId,
    layers:App.layers,activeLayerId:App.activeLayerId,layerCounter:App.layerCounter,
    frameCounter:App.frameCounter,selection:App.selection,selectionCells:App.selectionCells?[...App.selectionCells]:null
  });
}
function restoreSnapshot(raw){
  const s=JSON.parse(raw);
  App.width=s.width;App.height=s.height;App.frames=s.frames;App.activeFrameId=s.activeFrameId;
  App.layers=s.layers;App.activeLayerId=s.activeLayerId;App.layerCounter=s.layerCounter;
  App.frameCounter=s.frameCounter;App.selection=s.selection||null;App.selectionCells=s.selectionCells?new Set(s.selectionCells):null;App.selectedPixels=null;App.selectionMode=null;
  resizeCanvas();saveTab();renderFrames();renderLayers();refreshGhostControls();draw();updateHistoryButtons();
}
function pushHistory(label='Edit'){
  if(App.isPlaying)return;
  App.undoStack=App.undoStack||[];App.redoStack=App.redoStack||[];
  App.undoStack.push(snapshotCurrent());
  if(App.undoStack.length>40)App.undoStack.shift();
  App.redoStack=[];App.historyLabel=label;updateHistoryButtons();
}
function undo(){
  if(!App.undoStack||!App.undoStack.length)return;
  App.redoStack=App.redoStack||[];App.redoStack.push(snapshotCurrent());
  restoreSnapshot(App.undoStack.pop());
}
function redo(){
  if(!App.redoStack||!App.redoStack.length)return;
  App.undoStack=App.undoStack||[];App.undoStack.push(snapshotCurrent());
  restoreSnapshot(App.redoStack.pop());
}
function updateHistoryButtons(){
  if($('undoBtn'))$('undoBtn').disabled=!(App.undoStack&&App.undoStack.length);
  if($('redoBtn'))$('redoBtn').disabled=!(App.redoStack&&App.redoStack.length);
}
function resetHistory(){App.undoStack=[];App.redoStack=[];updateHistoryButtons()}

function updateSelectionUI(){
  const has=!!App.selection;
  const moving=App.selectionMode==='move'&&!!App.selectedPixels;
  const float=$('floatingSelectionActions');
  if(float)float.classList.toggle('hidden',!has);
  if($('floatDeselectBtn'))$('floatDeselectBtn').disabled=!has;
  if($('floatDeleteBtn'))$('floatDeleteBtn').disabled=!has;
}
function setPercentPair(rangeId,numberId,value,cb){
  const min=Number($(rangeId).min||0),max=Number($(rangeId).max||100);
  const v=Math.max(min,Math.min(max,Number(value)||0));
  $(rangeId).value=v;$(numberId).value=v;if(cb)cb(v);
}
