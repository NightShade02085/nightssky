Night’s Sky V6

How to run:
1. Unzip this folder.
2. Open index.html in Edge, Chrome, Brave, or Firefox.
3. Keep the css, js, libs, and projects folders together.

V5 changes:
- Added Deselect for active selections and Esc to deselect.
- Tool dropdown menus now open only on second-click of the currently selected tool.
- Added playback controls for Forward/Reverse and Loop/Ping-Pong.
- Added drag-and-drop frame reordering in the timeline.
- Added drag-and-drop layer reordering in the layer menu.
- Collapsed Color panel still shows a live editable active color chip.
- Removed separate Ghost On template button; Toggle Ghost remains.
- Renamed template Load button to Paste On Canvas.
- Canvas section is now a collapsed dropdown by default.
- Import Image and Export Project buttons are now matching rectangular controls with spacing.
- Added Template Quickbar option with Paste Template, Toggle Ghost, and template selector.
- Added template preview thumbnail in the template panel.
- Export wizard now includes scale, background color, and GIF timing settings.
- Kept free-hand lasso and box lasso selection tools.

Notes:
- Browser security still prevents silently saving into an app folder. Use Projects Folder in Chromium browsers to grant folder access, or use normal downloads as fallback.


V7 patch:
- Fixed modal/editor closing when selecting or dragging text inside sub-windows.
- Disabled accidental text selection on buttons, tabs, tools, frames, layers, and swatches.
- Kept input boxes, textareas, dropdowns, and modal text fields selectable/editable.

V7.1 tweak:
- Added tasteful orange Ko-fi support button below Export Project in the toolbar.
